import { Component } from '@angular/core';

export type EditorType = 'fan' | 'talent';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Hash';
  // editor: EditorType = 'name';
  editor: EditorType = 'fan';

  get showNameEditor() {
    return this.editor === 'fan';
  }

  get showProfileEditor() {
    return this.editor === 'talent';
  }

  toggleEditor(type: EditorType) {
    this.editor = type;
  }
}
